<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy-DNS管理系统</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
-->
</style>
</head>

<body>
<p class="STYLE1">Easy-DNS管理系统</p>
<p class="STYLE1">&nbsp;</p>
<table width="320" border="0">
  <tr>
    <td width="62"><div align="center"><a href="admin.php">首页</a></div></td>
    <td width="80"><div align="center"><a href="userlist.php">用户管理</a></div></td>
    <td width="80"><div align="center"><a href="domain.php">域名管理</a></div></td>
    <td width="80"><div align="center"><a href="<?php echo $logoutAction ?>">退出系统</a></div></td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
