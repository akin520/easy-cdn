<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_bind = "192.168.1.252";
$database_bind = "dns";
$username_bind = "root";
$password_bind = "root";
$bind = mysql_pconnect($hostname_bind, $username_bind, $password_bind) or trigger_error(mysql_error(),E_USER_ERROR); 
?>