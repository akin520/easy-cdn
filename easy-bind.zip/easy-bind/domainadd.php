<?php require_once('Connections/bind.php'); ?><?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO dns_records (`zone`, `host`, type, `data`, ttl, contact, mx_priority, refresh, retry, expire, minimum, serial, resp_person, primary_ns) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['zone'], "text"),
                       GetSQLValueString($_POST['host'], "text"),
                       GetSQLValueString($_POST['type'], "text"),
                       GetSQLValueString($_POST['data'], "text"),
                       GetSQLValueString($_POST['ttl'], "int"),
                       GetSQLValueString($_POST['contact'], "text"),
                       GetSQLValueString($_POST['mx_priority'], "text"),
                       GetSQLValueString($_POST['refresh'], "int"),
                       GetSQLValueString($_POST['retry'], "int"),
                       GetSQLValueString($_POST['expire'], "int"),
                       GetSQLValueString($_POST['minimum'], "int"),
                       GetSQLValueString($_POST['serial'], "int"),
                       GetSQLValueString($_POST['resp_person'], "text"),
                       GetSQLValueString($_POST['primary_ns'], "text"));

  mysql_select_db($database_bind, $bind);
  $Result1 = mysql_query($insertSQL, $bind) or die(mysql_error());

  $insertGoTo = "domain.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy-DNS管理系统</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
.STYLE8 {color: #FF0000}
-->
</style>
</head>

<body>
<p class="STYLE1">Easy-DNS管理系统</p>
<p class="STYLE1">&nbsp;</p>
<table width="320" border="0">
  <tr>
    <td width="62"><div align="center"><a href="admin.php">首页</a></div></td>
    <td width="80"><div align="center"><a href="userlist.php">用户管理</a></div></td>
    <td width="80"><div align="center"><a href="domain.php">域名管理</a></div></td>
    <td width="80"><div align="center"><a href="<?php echo $logoutAction ?>">退出系统</a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="352" height="506" border="1" cellpadding="0" cellspacing="0">
  <tr>
    <td width="348" height="38" background="images/default-bg.gif"><div align="center"><span class="STYLE1">域名添加</span></div></td>
  </tr>
  <tr>
    <td height="466"><form action="<?php echo $editFormAction; ?>" method="POST" enctype="multipart/form-data" name="form1" id="form1">
      <table width="326" height="283" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="142"><div align="center">zone<span class="STYLE8">*</span></div></td>
          <td width="178"><label>
                <div align="left">
                  <input name="zone" type="text" id="zone" value="easy-cdn.cn" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">host<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="host" type="text" id="host" value="www" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td height="23"><div align="center">type<span class="STYLE8">*</span></div></td>
          <td><div align="left">
            <label>
              <select name="type" id="type">
                <option value="A" selected="selected">A</option>
                <option value="CNAME">CNAME</option>
                <option value="MX">MX</option>
                <option value="NS">NS</option>
                <option value="PTR">PTR</option>
                <option value="TXT">TXT</option>
              </select>
              </label>
          </div></td>
        </tr>
        <tr>
          <td height="23"><div align="center">data<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="data" type="text" id="data" value="192.168.1.1" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">contact</div></td>
          <td><label>
                <div align="left">
                  <input name="contact" type="text" id="contact" value="测试" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">ttl<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="ttl" type="text" id="ttl" value="600" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">mx_priority</div></td>
          <td><label>
                <div align="left">
                  <input name="mx_priority" type="text" id="mx_priority" value="" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">refresh</div></td>
          <td><label>
                <div align="left">
                  <input name="refresh" type="text" id="refresh" value="28800" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">retry<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="retry" type="text" id="retry" value="3600" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">expire</div></td>
          <td><label>
                <div align="left">
                  <input name="expire" type="text" id="expire" value="604800" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">minimum</div></td>
          <td><label>
                <div align="left">
                  <input name="minimum" type="text" id="minimum" value="3600" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">serial</div></td>
          <td><label>
                <div align="left">
                  <input name="serial" type="text" id="serial" value="<?php echo date("YmdH"); ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">resp_person</div></td>
          <td><label>
                <div align="left">
                  <input name="resp_person" type="text" id="resp_person" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">primary_ns</div></td>
          <td><label>
                <div align="left">
                  <input name="primary_ns" type="text" id="primary_ns" />
                </div>
            </label></td>
        </tr>
      </table>
      <label></label>
      <p>
      <label>
      <div align="center">
      <div align="center">
        <input type="submit" name="Submit" value="添加" />
        <input type="reset" name="Submit2" value="重写" />
      </div>
      </label>
      <p>&nbsp;</p>
      <input type="hidden" name="MM_insert" value="form1" />
    </form>
        <p class="STYLE8">注意：ttl refresh retry expire minimum serial为数字，打*写必写!</p></td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
