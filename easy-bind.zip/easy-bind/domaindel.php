<?php require_once('Connections/bind.php'); ?><?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['id'])) && ($_GET['id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM dns_records WHERE id=%s",
                       GetSQLValueString($_GET['id'], "int"));

  mysql_select_db($database_bind, $bind);
  $Result1 = mysql_query($deleteSQL, $bind) or die(mysql_error());

  $deleteGoTo = "domain.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_domaindel = "-1";
if (isset($_GET['id'])) {
  $colname_domaindel = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_bind, $bind);
$query_domaindel = sprintf("SELECT * FROM dns_records WHERE id = %s", GetSQLValueString($colname_domaindel, "int"));
$domaindel = mysql_query($query_domaindel, $bind) or die(mysql_error());
$row_domaindel = mysql_fetch_assoc($domaindel);
$totalRows_domaindel = mysql_num_rows($domaindel);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy-DNS管理系统</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
.STYLE8 {color: #FF0000}
-->
</style>
</head>

<body>
<p class="STYLE1">Easy-DNS管理系统</p>
<p class="STYLE1">&nbsp;</p>
<table width="320" border="0">
  <tr>
    <td width="62"><div align="center"><a href="admin.php">首页</a></div></td>
    <td width="80"><div align="center"><a href="userlist.php">用户管理</a></div></td>
    <td width="80"><div align="center"><a href="domain.php">域名管理</a></div></td>
    <td width="80"><div align="center"><a href="<?php echo $logoutAction ?>">退出系统</a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="352" height="506" border="1" cellpadding="0" cellspacing="0">
  <tr>
    <td width="348" height="38" background="images/default-bg.gif"><div align="center"><span class="STYLE1">域名删除</span></div></td>
  </tr>
  <tr>
    <td height="466"><form method="POST" enctype="multipart/form-data" name="form1" id="form1">
      <table width="326" height="283" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="142"><div align="center">zone<span class="STYLE8">*</span></div></td>
          <td width="178"><label>
                <div align="left">
                  <input name="zone" type="text" id="zone" value="<?php echo $row_domaindel['zone']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">host<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="host" type="text" id="host" value="<?php echo $row_domaindel['host']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td height="23"><div align="center">type<span class="STYLE8">*</span></div></td>
          <td><div align="left">
            <label>
              <select name="type" id="type">
                <option value="A" selected="selected" <?php if (!(strcmp("A", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>A</option>
                <option value="CNAME" <?php if (!(strcmp("CNAME", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>CNAME</option>
                <option value="MX" <?php if (!(strcmp("MX", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>MX</option>
                <option value="NS" <?php if (!(strcmp("NS", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>NS</option>
                <option value="PTR" <?php if (!(strcmp("PTR", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>PTR</option>
                <option value="TXT" <?php if (!(strcmp("TXT", $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>>TXT</option>
                <?php
do {  
?>
                <option value="<?php echo $row_domaindel['type']?>"<?php if (!(strcmp($row_domaindel['type'], $row_domaindel['type']))) {echo "selected=\"selected\"";} ?>><?php echo $row_domaindel['type']?></option>
                <?php
} while ($row_domaindel = mysql_fetch_assoc($domaindel));
  $rows = mysql_num_rows($domaindel);
  if($rows > 0) {
      mysql_data_seek($domaindel, 0);
	  $row_domaindel = mysql_fetch_assoc($domaindel);
  }
?>
              </select>
              </label>
          </div></td>
        </tr>
        <tr>
          <td height="23"><div align="center">data<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="data" type="text" id="data" value="<?php echo $row_domaindel['data']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">contact</div></td>
          <td><label>
                <div align="left">
                  <input name="contact" type="text" id="contact" value="<?php echo $row_domaindel['contact']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">ttl<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="ttl" type="text" id="ttl" value="<?php echo $row_domaindel['ttl']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">mx_priority</div></td>
          <td><label>
                <div align="left">
                  <input name="mx_priority" type="text" id="mx_priority" value="<?php echo $row_domaindel['mx_priority']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">refresh</div></td>
          <td><label>
                <div align="left">
                  <input name="refresh" type="text" id="refresh" value="<?php echo $row_domaindel['refresh']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">retry<span class="STYLE8">*</span></div></td>
          <td><label>
                <div align="left">
                  <input name="retry" type="text" id="retry" value="<?php echo $row_domaindel['retry']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">expire</div></td>
          <td><label>
                <div align="left">
                  <input name="expire" type="text" id="expire" value="<?php echo $row_domaindel['expire']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">minimum</div></td>
          <td><label>
                <div align="left">
                  <input name="minimum" type="text" id="minimum" value="<?php echo $row_domaindel['minimum']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">serial</div></td>
          <td><label>
                <div align="left">
                  <input name="serial" type="text" id="serial" value="<?php echo $row_domaindel['serial']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">resp_person</div></td>
          <td><label>
                <div align="left">
                  <input name="resp_person" type="text" id="resp_person" value="<?php echo $row_domaindel['resp_person']; ?>" />
                </div>
            </label></td>
        </tr>
        <tr>
          <td><div align="center">primary_ns</div></td>
          <td><label>
                <div align="left">
                  <input name="primary_ns" type="text" id="primary_ns" value="<?php echo $row_domaindel['primary_ns']; ?>" />
                </div>
            </label></td>
        </tr>
      </table>
      <label></label>
      <p>
      <label>
      <div align="center">
      <div align="center">
        <input type="submit" name="Submit" value="  删除  " />
        <input type="reset" name="Submit2" value="重写" />
      </div>
      </label>
      <p>
        <input name="id" type="hidden" id="id" value="<?php echo $row_domaindel['id']; ?>" />
      </p>
      
      
    </form>
        <p class="STYLE8">注意：ttl refresh retry expire minimum serial为数字，打*写必写!</p></td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
<?php
mysql_free_result($domaindel);
?>
