<?php require_once('Connections/bind.php'); ?>
<?php require_once('Connections/bind.php'); ?><?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_domain = 10;
$pageNum_domain = 0;
if (isset($_GET['pageNum_domain'])) {
  $pageNum_domain = $_GET['pageNum_domain'];
}
$startRow_domain = $pageNum_domain * $maxRows_domain;

mysql_select_db($database_bind, $bind);
$query_domain = "SELECT * FROM dns_records";
$query_limit_domain = sprintf("%s LIMIT %d, %d", $query_domain, $startRow_domain, $maxRows_domain);
$domain = mysql_query($query_limit_domain, $bind) or die(mysql_error());
$row_domain = mysql_fetch_assoc($domain);

if (isset($_GET['totalRows_domain'])) {
  $totalRows_domain = $_GET['totalRows_domain'];
} else {
  $all_domain = mysql_query($query_domain);
  $totalRows_domain = mysql_num_rows($all_domain);
}
$totalPages_domain = ceil($totalRows_domain/$maxRows_domain)-1;

$queryString_domain = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_domain") == false && 
        stristr($param, "totalRows_domain") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_domain = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_domain = sprintf("&totalRows_domain=%d%s", $totalRows_domain, $queryString_domain);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy-DNS管理系统</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
.STYLE2 {
	font-size: x-small;
	color: #FF0000;
}
-->
</style>
<script type="text/javascript">
function on_del(id){
	if (confirm('是否删除?')){
		location='domaindel.php?id='+id;
	}
}
</script>
</head>
</head>

<body>
<p class="STYLE1">Easy-DNS管理系统</p>
<p class="STYLE1">&nbsp;</p>
<table width="320" border="0">
  <tr>
    <td width="62"><div align="center"><a href="admin.php">首页</a></div></td>
    <td width="80"><div align="center"><a href="userlist.php">用户管理</a></div></td>
    <td width="80"><div align="center"><a href="domain.php">域名管理</a></div></td>
    <td width="80"><div align="center"><a href="<?php echo $logoutAction ?>">退出系统</a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
<p><a href="domainadd.php">域名添加</a></p>
<p>域名列表(总共<?php echo $totalRows_domain ?> 个域名):</p>
<table width="926" border="1">
  <tr>
    <td width="148"><div align="center">ZONE</div></td>
    <td width="125"><div align="center">HOST</div></td>
    <td width="89"><div align="center">TYPE</div></td>
    <td width="140"><div align="center">DATA</div></td>
    <td width="81"><div align="center">TTL</div></td>
    <td width="179"><div align="center">CONTACT</div></td>
    <td width="118"><div align="center">操作</div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><div align="center"><?php echo $row_domain['zone']; ?></div></td>
      <td><div align="center"><?php echo $row_domain['host']; ?></div></td>
      <td><div align="center"><?php echo $row_domain['type']; ?></div></td>
      <td><div align="center"><?php echo $row_domain['data']; ?></div></td>
      <td><div align="center"><?php echo $row_domain['ttl']; ?></div></td>
      <td><div align="center"><?php echo $row_domain['contact']; ?></div></td>
      <td><div align="center"><a href="domainedit.php?id=<?php echo $row_domain['id']; ?>">编辑</a> <a href="javascript:void(0);" onclick="javascript:on_del('<?php echo $row_domain['id']; ?>'); ">删除</a> </div></td>
    </tr>
    <?php } while ($row_domain = mysql_fetch_assoc($domain)); ?>
</table>
<table width="273" border="1">
  <tr>
    <td width="56"><a href="<?php printf("%s?pageNum_domain=%d%s", $currentPage, 0, $queryString_domain); ?>">第一页</a> </td>
    <td width="52"><a href="<?php printf("%s?pageNum_domain=%d%s", $currentPage, min($totalPages_domain, $pageNum_domain + 1), $queryString_domain); ?>">下一页</a></td>
    <td width="58"><a href="<?php printf("%s?pageNum_domain=%d%s", $currentPage, max(0, $pageNum_domain - 1), $queryString_domain); ?>">上一页</a></td>
    <td width="79"><a href="<?php printf("%s?pageNum_domain=%d%s", $currentPage, $totalPages_domain, $queryString_domain); ?>">最后一页</a> </td>
  </tr>
</table>
<p>域名查找：</p>
<form id="form1" name="form1" method="post" action="find.php">
  <label>关键字：
  <input name="key" type="text" id="key" size="40" />
  </label>
  <label>
  <input type="submit" name="Submit" value="查找" />
  </label>
</form>
<p class="STYLE2">可以查找zone及contact中的关键字!!</p>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($domain);
?>
