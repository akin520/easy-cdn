<?php require_once('Connections/bind.php'); ?><?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$colname_find = "-1";
if (isset($_POST['key'])) {
  $colname_find = (get_magic_quotes_gpc()) ? $_POST['key'] : addslashes($_POST['key']);
}
$colname1_find = "-1";
if (isset($_POST['key'])) {
  $colname1_find = (get_magic_quotes_gpc()) ? $_POST['key'] : addslashes($_POST['key']);
}
mysql_select_db($database_bind, $bind);
$query_find = sprintf("SELECT * FROM dns_records WHERE `zone` LIKE CONCAT('%%', %s, '%%') OR `contact` LIKE CONCAT('%%', %s, '%%');", GetSQLValueString($colname_find, "text"),GetSQLValueString($colname1_find, "text"));
$find = mysql_query($query_find, $bind) or die(mysql_error());
$row_find = mysql_fetch_assoc($find);
$totalRows_find = mysql_num_rows($find);

$queryString_find = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_find") == false && 
        stristr($param, "totalRows_find") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_find = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_find = sprintf("&totalRows_find=%d%s", $totalRows_find, $queryString_find);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy-DNS管理系统</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
-->
</style>
</head>

<body>
<p class="STYLE1">Easy-DNS管理系统</p>
<p class="STYLE1">&nbsp;</p>
<table width="320" border="0">
  <tr>
    <td width="62"><div align="center"><a href="admin.php">首页</a></div></td>
    <td width="80"><div align="center"><a href="userlist.php">用户管理</a></div></td>
    <td width="80"><div align="center"><a href="domain.php">域名管理</a></div></td>
    <td width="80"><div align="center"><a href="<?php echo $logoutAction ?>">退出系统</a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>共找到 <?php echo $totalRows_find ?> 个域名</p>
<table width="926" border="1">
  <tr>
    <td width="148"><div align="center">ZONE</div></td>
    <td width="125"><div align="center">HOST</div></td>
    <td width="89"><div align="center">TYPE</div></td>
    <td width="140"><div align="center">DATA</div></td>
    <td width="81"><div align="center">TTL</div></td>
    <td width="179"><div align="center">CONTACT</div></td>
    <td width="118"><div align="center">操作</div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><div align="center"><?php echo $row_find['zone']; ?></div></td>
      <td><div align="center"><?php echo $row_find['host']; ?></div></td>
      <td><div align="center"><?php echo $row_find['type']; ?></div></td>
      <td><div align="center"><?php echo $row_find['data']; ?></div></td>
      <td><div align="center"><?php echo $row_find['ttl']; ?></div></td>
      <td><div align="center"><?php echo $row_find['contact']; ?></div></td>
      <td><div align="center"><a href="domainedit.php?id=<?php echo $row_find['id']; ?>">编辑</a> <a href="javascript:if(confirm('确定删除？')){location='domaindel.php?id=<?php echo $row_find['id']; ?>'}">删除</a> </div></td>
    </tr>
    <?php } while ($row_find = mysql_fetch_assoc($find)); ?>
</table>
<p>&nbsp; </p>
</body>
</html>
<?php
mysql_free_result($find);
?>
